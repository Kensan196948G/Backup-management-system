--
-- PostgreSQL database dump
--

\restrict svPtF82PRjdTHugWzSfecxdzrld8K2Bp9ukZLR9aGEYsqYZi64kGiEPwNxXCjrt

-- Dumped from database version 16.10 (Ubuntu 16.10-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.10 (Ubuntu 16.10-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA public;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alerts; Type: TABLE; Schema: public; Owner: backupmgmt
--

CREATE TABLE public.alerts (
    id integer NOT NULL,
    alert_type character varying(50) NOT NULL,
    severity character varying(20) NOT NULL,
    job_id integer,
    title character varying(200) NOT NULL,
    message text NOT NULL,
    is_acknowledged boolean NOT NULL,
    acknowledged_by integer,
    acknowledged_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.alerts OWNER TO backupmgmt;

--
-- Name: alerts_id_seq; Type: SEQUENCE; Schema: public; Owner: backupmgmt
--

CREATE SEQUENCE public.alerts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.alerts_id_seq OWNER TO backupmgmt;

--
-- Name: alerts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: backupmgmt
--

ALTER SEQUENCE public.alerts_id_seq OWNED BY public.alerts.id;


--
-- Name: apscheduler_jobs; Type: TABLE; Schema: public; Owner: backupmgmt
--

CREATE TABLE public.apscheduler_jobs (
    id character varying(191) NOT NULL,
    next_run_time double precision,
    job_state bytea NOT NULL
);


ALTER TABLE public.apscheduler_jobs OWNER TO backupmgmt;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: backupmgmt
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    user_id integer,
    action_type character varying(50) NOT NULL,
    resource_type character varying(50),
    resource_id integer,
    ip_address character varying(45),
    action_result character varying(20) NOT NULL,
    details text,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO backupmgmt;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: backupmgmt
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_logs_id_seq OWNER TO backupmgmt;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: backupmgmt
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: backup_copies; Type: TABLE; Schema: public; Owner: backupmgmt
--

CREATE TABLE public.backup_copies (
    id integer NOT NULL,
    job_id integer NOT NULL,
    copy_type character varying(20) NOT NULL,
    media_type character varying(20) NOT NULL,
    storage_path character varying(500),
    is_encrypted boolean NOT NULL,
    is_compressed boolean NOT NULL,
    last_backup_date timestamp without time zone,
    last_backup_size bigint,
    status character varying(20) NOT NULL,
    offline_media_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.backup_copies OWNER TO backupmgmt;

--
-- Name: backup_copies_id_seq; Type: SEQUENCE; Schema: public; Owner: backupmgmt
--

CREATE SEQUENCE public.backup_copies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.backup_copies_id_seq OWNER TO backupmgmt;

--
-- Name: backup_copies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: backupmgmt
--

ALTER SEQUENCE public.backup_copies_id_seq OWNED BY public.backup_copies.id;


--
-- Name: backup_executions; Type: TABLE; Schema: public; Owner: backupmgmt
--

CREATE TABLE public.backup_executions (
    id integer NOT NULL,
    job_id integer NOT NULL,
    execution_date timestamp without time zone NOT NULL,
    execution_result character varying(20) NOT NULL,
    error_message text,
    backup_size_bytes bigint,
    duration_seconds integer,
    source_system character varying(100),
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.backup_executions OWNER TO backupmgmt;

--
-- Name: backup_executions_id_seq; Type: SEQUENCE; Schema: public; Owner: backupmgmt
--

CREATE SEQUENCE public.backup_executions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.backup_executions_id_seq OWNER TO backupmgmt;

--
-- Name: backup_executions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: backupmgmt
--

ALTER SEQUENCE public.backup_executions_id_seq OWNED BY public.backup_executions.id;


--
-- Name: backup_jobs; Type: TABLE; Schema: public; Owner: backupmgmt
--

CREATE TABLE public.backup_jobs (
    id integer NOT NULL,
    job_name character varying(100) NOT NULL,
    job_type character varying(50) NOT NULL,
    target_server character varying(100),
    target_path character varying(500),
    backup_tool character varying(50) NOT NULL,
    schedule_type character varying(20) NOT NULL,
    retention_days integer NOT NULL,
    owner_id integer NOT NULL,
    description text,
    is_active boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.backup_jobs OWNER TO backupmgmt;

--
-- Name: backup_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: backupmgmt
--

CREATE SEQUENCE public.backup_jobs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.backup_jobs_id_seq OWNER TO backupmgmt;

--
-- Name: backup_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: backupmgmt
--

ALTER SEQUENCE public.backup_jobs_id_seq OWNED BY public.backup_jobs.id;


--
-- Name: compliance_status; Type: TABLE; Schema: public; Owner: backupmgmt
--

CREATE TABLE public.compliance_status (
    id integer NOT NULL,
    job_id integer NOT NULL,
    check_date timestamp without time zone NOT NULL,
    copies_count integer NOT NULL,
    media_types_count integer NOT NULL,
    has_offsite boolean NOT NULL,
    has_offline boolean NOT NULL,
    has_errors boolean NOT NULL,
    overall_status character varying(20) NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.compliance_status OWNER TO backupmgmt;

--
-- Name: compliance_status_id_seq; Type: SEQUENCE; Schema: public; Owner: backupmgmt
--

CREATE SEQUENCE public.compliance_status_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.compliance_status_id_seq OWNER TO backupmgmt;

--
-- Name: compliance_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: backupmgmt
--

ALTER SEQUENCE public.compliance_status_id_seq OWNED BY public.compliance_status.id;


--
-- Name: media_lending; Type: TABLE; Schema: public; Owner: backupmgmt
--

CREATE TABLE public.media_lending (
    id integer NOT NULL,
    offline_media_id integer NOT NULL,
    borrower_id integer NOT NULL,
    borrow_purpose character varying(200),
    borrow_date timestamp without time zone NOT NULL,
    expected_return date NOT NULL,
    actual_return timestamp without time zone,
    return_condition character varying(20),
    notes text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.media_lending OWNER TO backupmgmt;

--
-- Name: media_lending_id_seq; Type: SEQUENCE; Schema: public; Owner: backupmgmt
--

CREATE SEQUENCE public.media_lending_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.media_lending_id_seq OWNER TO backupmgmt;

--
-- Name: media_lending_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: backupmgmt
--

ALTER SEQUENCE public.media_lending_id_seq OWNED BY public.media_lending.id;


--
-- Name: media_rotation_schedule; Type: TABLE; Schema: public; Owner: backupmgmt
--

CREATE TABLE public.media_rotation_schedule (
    id integer NOT NULL,
    offline_media_id integer NOT NULL,
    rotation_type character varying(20) NOT NULL,
    rotation_cycle character varying(20) NOT NULL,
    next_rotation_date date NOT NULL,
    last_rotation_date date,
    is_active boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.media_rotation_schedule OWNER TO backupmgmt;

--
-- Name: media_rotation_schedule_id_seq; Type: SEQUENCE; Schema: public; Owner: backupmgmt
--

CREATE SEQUENCE public.media_rotation_schedule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.media_rotation_schedule_id_seq OWNER TO backupmgmt;

--
-- Name: media_rotation_schedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: backupmgmt
--

ALTER SEQUENCE public.media_rotation_schedule_id_seq OWNED BY public.media_rotation_schedule.id;


--
-- Name: notification_logs; Type: TABLE; Schema: public; Owner: backupmgmt
--

CREATE TABLE public.notification_logs (
    id integer NOT NULL,
    notification_type character varying(50) NOT NULL,
    channel character varying(50) NOT NULL,
    recipient character varying(255) NOT NULL,
    subject character varying(500),
    message text,
    severity character varying(20),
    status character varying(20) NOT NULL,
    error_message text,
    sent_at timestamp without time zone NOT NULL,
    alert_id integer,
    job_id integer,
    report_id integer,
    retry_count integer NOT NULL,
    delivery_time_ms integer
);


ALTER TABLE public.notification_logs OWNER TO backupmgmt;

--
-- Name: notification_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: backupmgmt
--

CREATE SEQUENCE public.notification_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notification_logs_id_seq OWNER TO backupmgmt;

--
-- Name: notification_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: backupmgmt
--

ALTER SEQUENCE public.notification_logs_id_seq OWNED BY public.notification_logs.id;


--
-- Name: offline_media; Type: TABLE; Schema: public; Owner: backupmgmt
--

CREATE TABLE public.offline_media (
    id integer NOT NULL,
    media_id character varying(50) NOT NULL,
    media_type character varying(20) NOT NULL,
    capacity_gb integer,
    purchase_date date,
    storage_location character varying(200),
    current_status character varying(20) NOT NULL,
    owner_id integer,
    qr_code text,
    notes text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.offline_media OWNER TO backupmgmt;

--
-- Name: offline_media_id_seq; Type: SEQUENCE; Schema: public; Owner: backupmgmt
--

CREATE SEQUENCE public.offline_media_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.offline_media_id_seq OWNER TO backupmgmt;

--
-- Name: offline_media_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: backupmgmt
--

ALTER SEQUENCE public.offline_media_id_seq OWNED BY public.offline_media.id;


--
-- Name: reports; Type: TABLE; Schema: public; Owner: backupmgmt
--

CREATE TABLE public.reports (
    id integer NOT NULL,
    report_type character varying(50) NOT NULL,
    report_title character varying(200) NOT NULL,
    date_from date NOT NULL,
    date_to date NOT NULL,
    file_path character varying(500),
    file_format character varying(10) NOT NULL,
    generated_by integer NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.reports OWNER TO backupmgmt;

--
-- Name: reports_id_seq; Type: SEQUENCE; Schema: public; Owner: backupmgmt
--

CREATE SEQUENCE public.reports_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.reports_id_seq OWNER TO backupmgmt;

--
-- Name: reports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: backupmgmt
--

ALTER SEQUENCE public.reports_id_seq OWNED BY public.reports.id;


--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: backupmgmt
--

CREATE TABLE public.system_settings (
    id integer NOT NULL,
    setting_key character varying(100) NOT NULL,
    setting_value text,
    value_type character varying(20) NOT NULL,
    description text,
    is_encrypted boolean NOT NULL,
    updated_by integer,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.system_settings OWNER TO backupmgmt;

--
-- Name: system_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: backupmgmt
--

CREATE SEQUENCE public.system_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.system_settings_id_seq OWNER TO backupmgmt;

--
-- Name: system_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: backupmgmt
--

ALTER SEQUENCE public.system_settings_id_seq OWNED BY public.system_settings.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: backupmgmt
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    email character varying(100) NOT NULL,
    password_hash character varying(255) NOT NULL,
    full_name character varying(100),
    department character varying(100),
    role character varying(20) NOT NULL,
    is_active boolean NOT NULL,
    last_login timestamp without time zone,
    failed_login_attempts integer NOT NULL,
    last_failed_login timestamp without time zone,
    account_locked_until timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.users OWNER TO backupmgmt;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: backupmgmt
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO backupmgmt;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: backupmgmt
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: verification_schedule; Type: TABLE; Schema: public; Owner: backupmgmt
--

CREATE TABLE public.verification_schedule (
    id integer NOT NULL,
    job_id integer NOT NULL,
    test_frequency character varying(20) NOT NULL,
    next_test_date date NOT NULL,
    last_test_date date,
    assigned_to integer,
    is_active boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.verification_schedule OWNER TO backupmgmt;

--
-- Name: verification_schedule_id_seq; Type: SEQUENCE; Schema: public; Owner: backupmgmt
--

CREATE SEQUENCE public.verification_schedule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.verification_schedule_id_seq OWNER TO backupmgmt;

--
-- Name: verification_schedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: backupmgmt
--

ALTER SEQUENCE public.verification_schedule_id_seq OWNED BY public.verification_schedule.id;


--
-- Name: verification_tests; Type: TABLE; Schema: public; Owner: backupmgmt
--

CREATE TABLE public.verification_tests (
    id integer NOT NULL,
    job_id integer NOT NULL,
    test_type character varying(50) NOT NULL,
    test_date timestamp without time zone NOT NULL,
    tester_id integer NOT NULL,
    restore_target character varying(200),
    test_result character varying(20) NOT NULL,
    duration_seconds integer,
    issues_found text,
    notes text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.verification_tests OWNER TO backupmgmt;

--
-- Name: verification_tests_id_seq; Type: SEQUENCE; Schema: public; Owner: backupmgmt
--

CREATE SEQUENCE public.verification_tests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.verification_tests_id_seq OWNER TO backupmgmt;

--
-- Name: verification_tests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: backupmgmt
--

ALTER SEQUENCE public.verification_tests_id_seq OWNED BY public.verification_tests.id;


--
-- Name: alerts id; Type: DEFAULT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.alerts ALTER COLUMN id SET DEFAULT nextval('public.alerts_id_seq'::regclass);


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: backup_copies id; Type: DEFAULT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.backup_copies ALTER COLUMN id SET DEFAULT nextval('public.backup_copies_id_seq'::regclass);


--
-- Name: backup_executions id; Type: DEFAULT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.backup_executions ALTER COLUMN id SET DEFAULT nextval('public.backup_executions_id_seq'::regclass);


--
-- Name: backup_jobs id; Type: DEFAULT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.backup_jobs ALTER COLUMN id SET DEFAULT nextval('public.backup_jobs_id_seq'::regclass);


--
-- Name: compliance_status id; Type: DEFAULT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.compliance_status ALTER COLUMN id SET DEFAULT nextval('public.compliance_status_id_seq'::regclass);


--
-- Name: media_lending id; Type: DEFAULT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.media_lending ALTER COLUMN id SET DEFAULT nextval('public.media_lending_id_seq'::regclass);


--
-- Name: media_rotation_schedule id; Type: DEFAULT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.media_rotation_schedule ALTER COLUMN id SET DEFAULT nextval('public.media_rotation_schedule_id_seq'::regclass);


--
-- Name: notification_logs id; Type: DEFAULT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.notification_logs ALTER COLUMN id SET DEFAULT nextval('public.notification_logs_id_seq'::regclass);


--
-- Name: offline_media id; Type: DEFAULT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.offline_media ALTER COLUMN id SET DEFAULT nextval('public.offline_media_id_seq'::regclass);


--
-- Name: reports id; Type: DEFAULT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.reports ALTER COLUMN id SET DEFAULT nextval('public.reports_id_seq'::regclass);


--
-- Name: system_settings id; Type: DEFAULT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.system_settings ALTER COLUMN id SET DEFAULT nextval('public.system_settings_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: verification_schedule id; Type: DEFAULT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.verification_schedule ALTER COLUMN id SET DEFAULT nextval('public.verification_schedule_id_seq'::regclass);


--
-- Name: verification_tests id; Type: DEFAULT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.verification_tests ALTER COLUMN id SET DEFAULT nextval('public.verification_tests_id_seq'::regclass);


--
-- Name: alerts alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_pkey PRIMARY KEY (id);


--
-- Name: apscheduler_jobs apscheduler_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.apscheduler_jobs
    ADD CONSTRAINT apscheduler_jobs_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: backup_copies backup_copies_pkey; Type: CONSTRAINT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.backup_copies
    ADD CONSTRAINT backup_copies_pkey PRIMARY KEY (id);


--
-- Name: backup_executions backup_executions_pkey; Type: CONSTRAINT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.backup_executions
    ADD CONSTRAINT backup_executions_pkey PRIMARY KEY (id);


--
-- Name: backup_jobs backup_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.backup_jobs
    ADD CONSTRAINT backup_jobs_pkey PRIMARY KEY (id);


--
-- Name: compliance_status compliance_status_pkey; Type: CONSTRAINT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.compliance_status
    ADD CONSTRAINT compliance_status_pkey PRIMARY KEY (id);


--
-- Name: media_lending media_lending_pkey; Type: CONSTRAINT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.media_lending
    ADD CONSTRAINT media_lending_pkey PRIMARY KEY (id);


--
-- Name: media_rotation_schedule media_rotation_schedule_pkey; Type: CONSTRAINT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.media_rotation_schedule
    ADD CONSTRAINT media_rotation_schedule_pkey PRIMARY KEY (id);


--
-- Name: notification_logs notification_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.notification_logs
    ADD CONSTRAINT notification_logs_pkey PRIMARY KEY (id);


--
-- Name: offline_media offline_media_pkey; Type: CONSTRAINT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.offline_media
    ADD CONSTRAINT offline_media_pkey PRIMARY KEY (id);


--
-- Name: reports reports_pkey; Type: CONSTRAINT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: verification_schedule verification_schedule_pkey; Type: CONSTRAINT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.verification_schedule
    ADD CONSTRAINT verification_schedule_pkey PRIMARY KEY (id);


--
-- Name: verification_tests verification_tests_pkey; Type: CONSTRAINT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.verification_tests
    ADD CONSTRAINT verification_tests_pkey PRIMARY KEY (id);


--
-- Name: ix_alerts_alert_type; Type: INDEX; Schema: public; Owner: backupmgmt
--

CREATE INDEX ix_alerts_alert_type ON public.alerts USING btree (alert_type);


--
-- Name: ix_alerts_created_at; Type: INDEX; Schema: public; Owner: backupmgmt
--

CREATE INDEX ix_alerts_created_at ON public.alerts USING btree (created_at);


--
-- Name: ix_alerts_is_acknowledged; Type: INDEX; Schema: public; Owner: backupmgmt
--

CREATE INDEX ix_alerts_is_acknowledged ON public.alerts USING btree (is_acknowledged);


--
-- Name: ix_alerts_severity; Type: INDEX; Schema: public; Owner: backupmgmt
--

CREATE INDEX ix_alerts_severity ON public.alerts USING btree (severity);


--
-- Name: ix_apscheduler_jobs_next_run_time; Type: INDEX; Schema: public; Owner: backupmgmt
--

CREATE INDEX ix_apscheduler_jobs_next_run_time ON public.apscheduler_jobs USING btree (next_run_time);


--
-- Name: ix_audit_logs_action_type; Type: INDEX; Schema: public; Owner: backupmgmt
--

CREATE INDEX ix_audit_logs_action_type ON public.audit_logs USING btree (action_type);


--
-- Name: ix_audit_logs_created_at; Type: INDEX; Schema: public; Owner: backupmgmt
--

CREATE INDEX ix_audit_logs_created_at ON public.audit_logs USING btree (created_at);


--
-- Name: ix_audit_logs_user_id; Type: INDEX; Schema: public; Owner: backupmgmt
--

CREATE INDEX ix_audit_logs_user_id ON public.audit_logs USING btree (user_id);


--
-- Name: ix_backup_copies_copy_type; Type: INDEX; Schema: public; Owner: backupmgmt
--

CREATE INDEX ix_backup_copies_copy_type ON public.backup_copies USING btree (copy_type);


--
-- Name: ix_backup_copies_job_id; Type: INDEX; Schema: public; Owner: backupmgmt
--

CREATE INDEX ix_backup_copies_job_id ON public.backup_copies USING btree (job_id);


--
-- Name: ix_backup_copies_media_type; Type: INDEX; Schema: public; Owner: backupmgmt
--

CREATE INDEX ix_backup_copies_media_type ON public.backup_copies USING btree (media_type);


--
-- Name: ix_backup_copies_offline_media_id; Type: INDEX; Schema: public; Owner: backupmgmt
--

CREATE INDEX ix_backup_copies_offline_media_id ON public.backup_copies USING btree (offline_media_id);


--
-- Name: ix_backup_executions_execution_date; Type: INDEX; Schema: public; Owner: backupmgmt
--

CREATE INDEX ix_backup_executions_execution_date ON public.backup_executions USING btree (execution_date);


--
-- Name: ix_backup_executions_execution_result; Type: INDEX; Schema: public; Owner: backupmgmt
--

CREATE INDEX ix_backup_executions_execution_result ON public.backup_executions USING btree (execution_result);


--
-- Name: ix_backup_executions_job_id; Type: INDEX; Schema: public; Owner: backupmgmt
--

CREATE INDEX ix_backup_executions_job_id ON public.backup_executions USING btree (job_id);


--
-- Name: ix_backup_jobs_is_active; Type: INDEX; Schema: public; Owner: backupmgmt
--

CREATE INDEX ix_backup_jobs_is_active ON public.backup_jobs USING btree (is_active);


--
-- Name: ix_backup_jobs_job_name; Type: INDEX; Schema: public; Owner: backupmgmt
--

CREATE INDEX ix_backup_jobs_job_name ON public.backup_jobs USING btree (job_name);


--
-- Name: ix_backup_jobs_job_type; Type: INDEX; Schema: public; Owner: backupmgmt
--

CREATE INDEX ix_backup_jobs_job_type ON public.backup_jobs USING btree (job_type);


--
-- Name: ix_backup_jobs_owner_id; Type: INDEX; Schema: public; Owner: backupmgmt
--

CREATE INDEX ix_backup_jobs_owner_id ON public.backup_jobs USING btree (owner_id);


--
-- Name: ix_compliance_status_check_date; Type: INDEX; Schema: public; Owner: backupmgmt
--

CREATE INDEX ix_compliance_status_check_date ON public.compliance_status USING btree (check_date);


--
-- Name: ix_compliance_status_job_id; Type: INDEX; Schema: public; Owner: backupmgmt
--

CREATE INDEX ix_compliance_status_job_id ON public.compliance_status USING btree (job_id);


--
-- Name: ix_compliance_status_overall_status; Type: INDEX; Schema: public; Owner: backupmgmt
--

CREATE INDEX ix_compliance_status_overall_status ON public.compliance_status USING btree (overall_status);


--
-- Name: ix_media_lending_actual_return; Type: INDEX; Schema: public; Owner: backupmgmt
--

CREATE INDEX ix_media_lending_actual_return ON public.media_lending USING btree (actual_return);


--
-- Name: ix_media_lending_borrower_id; Type: INDEX; Schema: public; Owner: backupmgmt
--

CREATE INDEX ix_media_lending_borrower_id ON public.media_lending USING btree (borrower_id);


--
-- Name: ix_media_lending_offline_media_id; Type: INDEX; Schema: public; Owner: backupmgmt
--

CREATE INDEX ix_media_lending_offline_media_id ON public.media_lending USING btree (offline_media_id);


--
-- Name: ix_media_rotation_schedule_next_rotation_date; Type: INDEX; Schema: public; Owner: backupmgmt
--

CREATE INDEX ix_media_rotation_schedule_next_rotation_date ON public.media_rotation_schedule USING btree (next_rotation_date);


--
-- Name: ix_media_rotation_schedule_offline_media_id; Type: INDEX; Schema: public; Owner: backupmgmt
--

CREATE INDEX ix_media_rotation_schedule_offline_media_id ON public.media_rotation_schedule USING btree (offline_media_id);


--
-- Name: ix_notification_logs_notification_type; Type: INDEX; Schema: public; Owner: backupmgmt
--

CREATE INDEX ix_notification_logs_notification_type ON public.notification_logs USING btree (notification_type);


--
-- Name: ix_notification_logs_sent_at; Type: INDEX; Schema: public; Owner: backupmgmt
--

CREATE INDEX ix_notification_logs_sent_at ON public.notification_logs USING btree (sent_at);


--
-- Name: ix_notification_logs_severity; Type: INDEX; Schema: public; Owner: backupmgmt
--

CREATE INDEX ix_notification_logs_severity ON public.notification_logs USING btree (severity);


--
-- Name: ix_notification_logs_status; Type: INDEX; Schema: public; Owner: backupmgmt
--

CREATE INDEX ix_notification_logs_status ON public.notification_logs USING btree (status);


--
-- Name: ix_offline_media_current_status; Type: INDEX; Schema: public; Owner: backupmgmt
--

CREATE INDEX ix_offline_media_current_status ON public.offline_media USING btree (current_status);


--
-- Name: ix_offline_media_media_id; Type: INDEX; Schema: public; Owner: backupmgmt
--

CREATE UNIQUE INDEX ix_offline_media_media_id ON public.offline_media USING btree (media_id);


--
-- Name: ix_offline_media_media_type; Type: INDEX; Schema: public; Owner: backupmgmt
--

CREATE INDEX ix_offline_media_media_type ON public.offline_media USING btree (media_type);


--
-- Name: ix_reports_created_at; Type: INDEX; Schema: public; Owner: backupmgmt
--

CREATE INDEX ix_reports_created_at ON public.reports USING btree (created_at);


--
-- Name: ix_reports_report_type; Type: INDEX; Schema: public; Owner: backupmgmt
--

CREATE INDEX ix_reports_report_type ON public.reports USING btree (report_type);


--
-- Name: ix_system_settings_setting_key; Type: INDEX; Schema: public; Owner: backupmgmt
--

CREATE UNIQUE INDEX ix_system_settings_setting_key ON public.system_settings USING btree (setting_key);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: backupmgmt
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_role; Type: INDEX; Schema: public; Owner: backupmgmt
--

CREATE INDEX ix_users_role ON public.users USING btree (role);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: backupmgmt
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: ix_verification_schedule_job_id; Type: INDEX; Schema: public; Owner: backupmgmt
--

CREATE INDEX ix_verification_schedule_job_id ON public.verification_schedule USING btree (job_id);


--
-- Name: ix_verification_schedule_next_test_date; Type: INDEX; Schema: public; Owner: backupmgmt
--

CREATE INDEX ix_verification_schedule_next_test_date ON public.verification_schedule USING btree (next_test_date);


--
-- Name: ix_verification_tests_job_id; Type: INDEX; Schema: public; Owner: backupmgmt
--

CREATE INDEX ix_verification_tests_job_id ON public.verification_tests USING btree (job_id);


--
-- Name: ix_verification_tests_test_date; Type: INDEX; Schema: public; Owner: backupmgmt
--

CREATE INDEX ix_verification_tests_test_date ON public.verification_tests USING btree (test_date);


--
-- Name: ix_verification_tests_test_result; Type: INDEX; Schema: public; Owner: backupmgmt
--

CREATE INDEX ix_verification_tests_test_result ON public.verification_tests USING btree (test_result);


--
-- Name: alerts alerts_acknowledged_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_acknowledged_by_fkey FOREIGN KEY (acknowledged_by) REFERENCES public.users(id);


--
-- Name: alerts alerts_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.backup_jobs(id);


--
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: backup_copies backup_copies_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.backup_copies
    ADD CONSTRAINT backup_copies_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.backup_jobs(id);


--
-- Name: backup_copies backup_copies_offline_media_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.backup_copies
    ADD CONSTRAINT backup_copies_offline_media_id_fkey FOREIGN KEY (offline_media_id) REFERENCES public.offline_media(id);


--
-- Name: backup_executions backup_executions_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.backup_executions
    ADD CONSTRAINT backup_executions_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.backup_jobs(id);


--
-- Name: backup_jobs backup_jobs_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.backup_jobs
    ADD CONSTRAINT backup_jobs_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id);


--
-- Name: compliance_status compliance_status_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.compliance_status
    ADD CONSTRAINT compliance_status_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.backup_jobs(id);


--
-- Name: media_lending media_lending_borrower_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.media_lending
    ADD CONSTRAINT media_lending_borrower_id_fkey FOREIGN KEY (borrower_id) REFERENCES public.users(id);


--
-- Name: media_lending media_lending_offline_media_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.media_lending
    ADD CONSTRAINT media_lending_offline_media_id_fkey FOREIGN KEY (offline_media_id) REFERENCES public.offline_media(id);


--
-- Name: media_rotation_schedule media_rotation_schedule_offline_media_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.media_rotation_schedule
    ADD CONSTRAINT media_rotation_schedule_offline_media_id_fkey FOREIGN KEY (offline_media_id) REFERENCES public.offline_media(id);


--
-- Name: notification_logs notification_logs_alert_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.notification_logs
    ADD CONSTRAINT notification_logs_alert_id_fkey FOREIGN KEY (alert_id) REFERENCES public.alerts(id);


--
-- Name: notification_logs notification_logs_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.notification_logs
    ADD CONSTRAINT notification_logs_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.backup_jobs(id);


--
-- Name: notification_logs notification_logs_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.notification_logs
    ADD CONSTRAINT notification_logs_report_id_fkey FOREIGN KEY (report_id) REFERENCES public.reports(id);


--
-- Name: offline_media offline_media_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.offline_media
    ADD CONSTRAINT offline_media_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id);


--
-- Name: reports reports_generated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_generated_by_fkey FOREIGN KEY (generated_by) REFERENCES public.users(id);


--
-- Name: system_settings system_settings_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: verification_schedule verification_schedule_assigned_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.verification_schedule
    ADD CONSTRAINT verification_schedule_assigned_to_fkey FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: verification_schedule verification_schedule_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.verification_schedule
    ADD CONSTRAINT verification_schedule_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.backup_jobs(id);


--
-- Name: verification_tests verification_tests_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.verification_tests
    ADD CONSTRAINT verification_tests_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.backup_jobs(id);


--
-- Name: verification_tests verification_tests_tester_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: backupmgmt
--

ALTER TABLE ONLY public.verification_tests
    ADD CONSTRAINT verification_tests_tester_id_fkey FOREIGN KEY (tester_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

\unrestrict svPtF82PRjdTHugWzSfecxdzrld8K2Bp9ukZLR9aGEYsqYZi64kGiEPwNxXCjrt

